AdminCommand = {
   NoclipCommand = {
      EnableCommand = true,
      CommandName = 'noclip',
   },
   ReviveCommand = {
      EnableCommand = true,
      CommandName = 'revive',
   },
   HealCommand = {
      EnableCommand = true,
      CommandName = 'heal',
   },
   TelportToCoordsCommand = {
      EnableCommand = true,
      CommandName = 'tpc',
   },
   TeleportToMarkerCommand = {
      EnableCommand = true,
      CommandName = 'tpm',
   },
   KillCommand = {
      EnableCommand = true,
      CommandName = 'kill',
   },
   ReviveAllCommand = {
      EnableCommand = true,
      CommandName = 'reviveall',
   },
}