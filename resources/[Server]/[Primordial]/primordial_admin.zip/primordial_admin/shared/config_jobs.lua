Jobs = {
    {
        Label = 'Police',
        Name = 'police'
    },
    {
        Label = 'EMS',
        Name = 'ambulance'
    },
    {
        Label = 'Mechanic',
        Name = 'mechanic'
    },
    {
        Label = 'Car Dealer',
        Name = 'cardealer'
    },
    {
        Label = 'Unemployed',
        Name = 'unemployed'
    }
}