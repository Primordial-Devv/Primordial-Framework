webhooksConfig = {
    ['screenshot'] = {
        isEnable = true,
        webhookURL = 'https://canary.discord.com/api/webhooks/1267176905153581127/5TxOyuYlSd08pAngRhqBmt8UxWycQuMk8ngEGI99Qv2lRT8R5mcssv9HJVz4M2A6Y-Mf'
    }
}