banDuration = {
    {
        Name = "1 Hour",
        Duration = 1
    },
    {
        Name = "1 Day",
        Duration = 24
    },
    {
        Name = "1 Week",
        Duration = 168
    },
    {
        Name = "1 Month",
        Duration = 672
    },
    {
        Name = "Permanent",
        Duration = 'perm'
    }
}