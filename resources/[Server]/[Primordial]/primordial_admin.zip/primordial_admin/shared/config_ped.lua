PedSelection = {
    {
        Name = 'Reset',
        Model = 'restore'
    },
    {
        Name = 'Beach Lady',
        Model = 'a_f_m_beach_01'
    },
    {
        Name = 'Fat Lady',
        Model = 'a_f_m_fatbla_01'
    }
}