local isAccepted = false

if AdminCommand.NoclipCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.NoclipCommand.CommandName, {'admin'}, function(sPlayer)
        TriggerClientEvent('primordial_admin:client:toggleNoclip', sPlayer.source)
    end, false, {
        help = 'Put yourself in noclip mode.'
    })
end

if AdminCommand.ReviveCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.ReviveCommand.CommandName, {'admin'}, function(_, args)
        isAccepted = true
        args.playerId.triggerEvent('primordial_admin:client:revivePlayer', isAccepted)
    end, true, {
        help = 'Revive a player.',
        validate = true,
        arguments = {
            { name = "playerId", help = 'The id of player to revive', type = "player" },
        }
    })
end

if AdminCommand.HealCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.HealCommand.CommandName, {'admin'}, function(_, args)
        args.playerId.triggerEvent('primordial_lifeEssentials:client:healPlayer')
    end, true, {
        help = 'Heal a player.',
        validate = true,
        arguments = {
            { name = "playerId", help = 'The id of player to heal', type = "player" },
        }
    })
end

if AdminCommand.TelportToCoordsCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.TelportToCoordsCommand.CommandName, {'admin'}, function(sPlayer, args)
        sPlayer.setCoords({ x = args.x, y = args.y, z = args.z })
    end, false, {
        help = 'Teleport to the specified coordinates.',
        validate = true,
        arguments = {
            { name = "x", help = 'The x coordinate', type = "coordinate" },
            { name = "y", help = 'The y coordinate', type = "coordinate" },
            { name = "z", help = 'The z coordinate', type = "coordinate" },
        }
    })
end

if AdminCommand.TeleportToMarkerCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.TeleportToMarkerCommand.CommandName, {'admin'}, function(sPlayer)
        TriggerClientEvent('primordial_admin:client:teleportToMarker', sPlayer.source)
    end, false, {
        help = 'Teleport to the marker.'
    })
end

if AdminCommand.KillCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.KillCommand.CommandName, {'admin'}, function(_, args)
        args.playerId.triggerEvent("primordial_core:client:killPlayer")

    end, true, {
        help = 'Kill a player.',
        validate = true,
        arguments = {
            { name = "playerId", help = 'Kill the selectec player', type = "player" },
        },
    })
end


if AdminCommand.ReviveAllCommand.EnableCommand then
    PL.RegisterCommand(AdminCommand.ReviveAllCommand.CommandName, {'admin'}, function(sPlayer, args)
        for _, playerId in ipairs(GetPlayers()) do
            TriggerClientEvent('primordial_admin:client:revivePlayer', playerId, true)
        end

        lib.notify(sPlayer.source, {
            title = 'All players have been revived.',
            type = 'success'
        })
    end, false, {
        help = 'Revive all players connected to the server.',
    })
end