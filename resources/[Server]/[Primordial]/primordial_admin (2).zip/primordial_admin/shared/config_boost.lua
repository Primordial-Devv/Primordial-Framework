TorqueMultiplier = {
    {
        Name = 'Off',
        Value = 1.0
    },
    {
        Name = '25 %',
        Value = 4.0
    },
    {
        Name = '50 %',
        Value = 8.0
    },
    {
        Name = '75 %',
        Value = 10.0
    },
    {
        Name = '100%',
        Value = 100.0
    },
}