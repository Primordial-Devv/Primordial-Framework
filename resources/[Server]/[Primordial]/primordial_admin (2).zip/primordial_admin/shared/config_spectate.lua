spectateConfig = {
    takeScreenshot = {
        isEnable = true,
        button = 191,
    },
    revivePlayer = {
        isEnable = true,
        button = 29,
    },
    kickPlayer = {
        isEnable = true,
        button = 47,
    },
}