Weathers = {
    {
        label = 'Clear Skies',
        value = 'CLEAR'
    },
    {
        label = 'Extra Sunny',
        value = 'EXTRASUNNY'
    },
    {
        label = 'Cloudy',
        value = 'CLOUDS'
    },
    {
        label = 'Foggy',
        value = 'FOGGY'
    },
    {
        label = 'Thunder',
        value = 'THUNDER'
    },
    {
        label = 'Rainy',
        value = 'RAIN'
    },
    {
        label = 'Halloween',
        value = 'HALLOWEEN'
    },
    {
        label = 'Snow Light',
        value = 'SNOWLIGHT'
    },
    {
        label = 'XMAS',
        value = 'XMAS'
    }
}