Translations = {
    refuel_vehicle_target = "Refuel vehicle",
    buy_jerrycan_target = "Buy jerrycan"
}