PL = {}

exports("getSharedObject", function()
    return PL
end)