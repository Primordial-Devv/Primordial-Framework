--- Return a random string with the given length (letters and digits only)
---@param length number The length of the string to generate
---@return string randomString The random string generated
function PL.Print.GetRandomString(length)
    local Charset = {}

    for i = 48, 57 do
        table.insert(Charset, string.char(i))
    end

    for i = 65, 90 do
        table.insert(Charset, string.char(i))
    end

    for i = 97, 122 do
        table.insert(Charset, string.char(i))
    end

    math.randomseed(os.time() + math.random(1, 100000))

    local randomString = ""
    for i = 1, length do
        randomString = randomString .. Charset[math.random(1, #Charset)]
    end

    return randomString
end

return PL.Print.GetRandomString