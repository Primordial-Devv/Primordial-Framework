AccountsFramework = {
    bank = {
        label = Translations.account_bank,
        round = true,
    },
    black_money = {
        label = Translations.account_black_money,
        round = true,
    },
    money = {
        label = Translations.account_money,
        round = true,
    },
}

StartingAccountMoney = { bank = 50000 }

StartingInventoryItems = {
    {name = 'burger', count = 5, slot = 1},
    {name = 'water', count = 5, slot = 2},
    {name = 'money', count = 1500, slot = 3}
} -- table/false

DefaultSpawnPosition = {
    { x = 222.2027, y = -864.0162, z = 30.2922, heading = 1.0 },
}

PermissionsGroups = {
    ["owner"] = true,
    ["admin"] = true,
}

MaxEmployeeSalary = 3500

SocietyBossGrades = { -- Uncomment and/or add additional grades you want to have access to the boss menu.
    ['boss'] = true,
    ['second'] = true,
}

EnableDebug = false -- Use Debug options?