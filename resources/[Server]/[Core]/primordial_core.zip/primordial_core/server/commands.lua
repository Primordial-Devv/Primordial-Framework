PL.RegisterCommand("setjob", {'admin'}, function(sPlayer, args, showError)
    if not PL.DoesJobExist(args.job, args.grade) then
        return showError(Translations.command_setjob_invalid)
    end

    args.playerId.setJob(args.job, args.grade)

    PL.Discord.DiscordLogFields("UserActions", "Set Job /setjob Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Job", value = args.job, inline = true },
        { name = "Grade", value = args.grade, inline = true },
    })

end, true, {
    help = Translations.command_setjob,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
        { name = "job", help = Translations.command_setjob_job, type = "string" },
        { name = "grade", help = Translations.command_setjob_grade, type = "number" },
    },
})

local upgrades = true and {
    plate = "ADMINCAR",
    modEngine = 3,
    modBrakes = 2,
    modTransmission = 2,
    modSuspension = 3,
    modArmor = true,
    windowTint = 1,
} or {}

PL.RegisterCommand('car', {'admin'}, function(sPlayer, args, showError)
    PL.Print.Info("Car Command Triggered")
    if not sPlayer then
        PL.Print.Info("The sPlayer value is nil")
        return showError("[^1ERROR^7] The sPlayer value is nil")
    end
    PL.Print.Info("Car Command Triggered 2")

    local playerPed = GetPlayerPed(sPlayer.source)
    local playerCoords = GetEntityCoords(playerPed)
    local playerHeading = GetEntityHeading(playerPed)
    local playerVehicle = GetVehiclePedIsIn(playerPed, false)

    if not args.car or type(args.car) ~= "string" then
        args.car = "adder"
        PL.Print.Info('Car Set to Adder')
    end

    if playerVehicle then
        PL.Print.Info('Player Vehicle Exists')
        DeleteEntity(playerVehicle)
    end

    PL.Discord.DiscordLogFields("UserActions", "Spawn Car /car Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Vehicle", value = args.car, inline = true },
    })
    PL.Print.Info('Discord Log Fields')

    PL.Vehicle.SpawnServerVehicle(args.car, playerCoords, playerHeading, upgrades, function(networkId)
        PL.Print.Info('Spawn Server Vehicle Callback')
        if networkId then
            local vehicle = NetworkGetEntityFromNetworkId(networkId)
            for _ = 1, 20 do
                Wait(0)
                SetPedIntoVehicle(playerPed, vehicle, -1)

                if GetVehiclePedIsIn(playerPed, false) == vehicle then
                    break
                end
            end
            if GetVehiclePedIsIn(playerPed, false) ~= vehicle then
                showError("[^1ERROR^7] The player could not be seated in the vehicle")
            end
        end
    end)
    PL.Print.Info('Vehicle Spawned')
end, false, {
    help = Translations.command_car,
    validate = false,
    arguments = {
        { name = "car", validate = false, help = Translations.command_car_car, type = "string" },
    },
})

PL.RegisterCommand({ "cardel", "dv" }, {'admin'}, function(sPlayer, args)
    local PedVehicle = GetVehiclePedIsIn(GetPlayerPed(sPlayer.source), false)
    if DoesEntityExist(PedVehicle) then
        DeleteEntity(PedVehicle)
    end

    local Vehicles = PL.Vehicle.GetServerNearbyVehicles(GetEntityCoords(GetPlayerPed(sPlayer.source)), tonumber(args.radius) or 5.0)
    for i = 1, #Vehicles do
        local vehicleId = Vehicles[i].vehicle
        local Vehicle = NetworkGetEntityFromNetworkId(vehicleId)
        if DoesEntityExist(Vehicle) then
            DeleteEntity(Vehicle)
        end
    end

    PL.Discord.DiscordLogFields("UserActions", "Delete Vehicle /dv Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
    })

end, false, {
    help = Translations.command_cardel,
    validate = false,
    arguments = {
        { name = "radius", validate = false, help = Translations.command_cardel_radius, type = "number" },
    },
})

PL.RegisterCommand({ "fix", "repair" }, {'admin'}, function(sPlayer, args, showError)
    local xTarget = args.playerId
    local ped = GetPlayerPed(xTarget.source)
    local pedVehicle = GetVehiclePedIsIn(ped, false)
    if not pedVehicle or GetPedInVehicleSeat(pedVehicle, -1) ~= ped then
        showError(Translations.not_in_vehicle)
        return
    end
    xTarget.triggerEvent("primordial_core:client:repairPedVehicle")
    TriggerClientEvent('ox_lib:notify', sPlayer.source, {
        tile = Translations.command_repair_success,
        type = 'success',
    })
    if sPlayer.source ~= xTarget.source then
        TriggerClientEvent('ox_lib:notify', xTarget.source, {
            tile = Translations.command_repair_success_target,
            type = 'success',
        })
    end

    PL.Discord.DiscordLogFields("UserActions", "Fix Vehicle /fix Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = xTarget.name, inline = true },
    })

end, true, {
    help = Translations.command_repair,
    validate = false,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
    },
})

PL.RegisterCommand("setaccountmoney", {'admin'}, function(sPlayer, args, showError)
    if not args.playerId.getAccount(args.account) then
        return showError(Translations.command_giveaccountmoney_invalid)
    end
    args.playerId.setAccountMoney(args.account, args.amount, "Government Grant")

    PL.Discord.DiscordLogFields("UserActions", "Set Account Money /setaccountmoney Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Account", value = args.account, inline = true },
        { name = "Amount", value = args.amount, inline = true },
    })

end, true, {
    help = Translations.command_setaccountmoney,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
        { name = "account", help = Translations.command_giveaccountmoney_account, type = "string" },
        { name = "amount", help = Translations.command_setaccountmoney_amount, type = "number" },
    },
})

PL.RegisterCommand("giveaccountmoney", {'admin'}, function(sPlayer, args, showError)
    if not args.playerId.getAccount(args.account) then
        return showError(Translations.command_giveaccountmoney_invalid)
    end
    args.playerId.addAccountMoney(args.account, args.amount, "Government Grant")

    PL.Discord.DiscordLogFields("UserActions", "Give Account Money /giveaccountmoney Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Account", value = args.account, inline = true },
        { name = "Amount", value = args.amount, inline = true },
    })

end, true, {
    help = Translations.command_giveaccountmoney,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
        { name = "account", help = Translations.command_giveaccountmoney_account, type = "string" },
        { name = "amount", help = Translations.command_giveaccountmoney_amount, type = "number" },
    },
})

PL.RegisterCommand("removeaccountmoney", {'admin'}, function(sPlayer, args, showError)
    if not args.playerId.getAccount(args.account) then
        return showError(Translations.command_removeaccountmoney_invalid)
    end
    args.playerId.removeAccountMoney(args.account, args.amount, "Government Tax")

    PL.Discord.DiscordLogFields("UserActions", "Remove Account Money /removeaccountmoney Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Account", value = args.account, inline = true },
        { name = "Amount", value = args.amount, inline = true },
    })

end, true, {
    help = Translations.command_removeaccountmoney,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
        { name = "account", help = Translations.command_removeaccountmoney_account, type = "string" },
        { name = "amount", help = Translations.command_removeaccountmoney_amount, type = "number" },
    },
})

PL.RegisterCommand({ "clear", "cls" }, {'user', 'admin'}, function(sPlayer)
    sPlayer.triggerEvent("chat:clear")
end, false, {
    help = Translations.command_clear
})

PL.RegisterCommand({ "clearall", "clsall" }, {'admin'}, function(sPlayer)
    TriggerClientEvent("chat:clear", -1)

    PL.Discord.DiscordLogFields("UserActions", "Clear Chat /clearall Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
    })

end, true, {
    help = Translations.command_clearall
})

PL.RegisterCommand("refreshjobs", {'admin'}, function()
    PL.RefreshJobs()
end, true, {
    help = Translations.command_clearall
})

PL.RegisterCommand('setgroup', {'admin'}, function(sPlayer, args)
    if not args.playerId then
        args.playerId = sPlayer.source
    end

    if args.group == "superadmin" then
        args.group = "admin"
        PL.Print.Warning("[^3WARNING^7] ^5Superadmin^7 detected, setting group to ^5admin^7")
    end
    args.playerId.setGroup(args.group)

    PL.Discord.DiscordLogFields("UserActions", "/setgroup Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Group", value = args.group, inline = true },
    })
end, true, {
    help = Translations.command_setgroup,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
        { name = "group", help = Translations.command_setgroup_group, type = "string" },
    }
})

PL.RegisterCommand("save", {'admin'}, function(_, args)
    PL.SavePlayer(args.playerId)
    print(("[^2Info^0] Saved Player - ^5%s^0"):format(args.playerId.source))
end, true, {
    help = Translations.command_save,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
    },
})

PL.RegisterCommand("saveall", {'admin'}, function()
    PL.SavePlayers()
end, true, {
    help = Translations.command_saveall
})

PL.RegisterCommand('group', {'user', 'admin'}, function(sPlayer, _, _)
    PL.Print.Info((('%s, you are currently : ^5%s^0'):format(sPlayer.getName(), sPlayer.getGroup())))
end)

PL.RegisterCommand("job", {'user', 'admin'}, function(sPlayer)
    --print(("%s, your job is: ^5%s^0 - ^5%s^0"):format(sPlayer.getName(), sPlayer.getJob().name, sPlayer.getJob().grade_label))
    PL.Print.Info(("%s, your job is : ^5%s^0, and your job grade is : ^5%s^0"):format(sPlayer.getName(), sPlayer.getJob().name, sPlayer.getJob().grade_label))
end, false)

PL.RegisterCommand("info", {'user', 'admin'}, function(sPlayer)
    local job = sPlayer.getJob().name
    PL.Print.Info(("ID: ^5%s^0 | Name: ^5%s^0 | Group: ^5%s^0 | Job: ^5%s^0"):format(sPlayer.source, sPlayer.getName(), sPlayer.getGroup(), job))
    -- print(("^2ID: ^5%s^0 | ^2Name: ^5%s^0 | ^2Group: ^5%s^0 | ^2Job: ^5%s^0"):format(sPlayer.source, sPlayer.getName(), sPlayer.getGroup(), job))
end, false)

PL.RegisterCommand("coords", {'admin'}, function(sPlayer)
    local ped = GetPlayerPed(sPlayer.source)
    local coords = GetEntityCoords(ped, false)
    local heading = GetEntityHeading(ped)
    print(("Coords - Vector3: ^5%s^0"):format(vector3(coords.x, coords.y, coords.z)))
    print(("Coords - Vector4: ^5%s^0"):format(vector4(coords.x, coords.y, coords.z, heading)))
end, false, {
    help = Translations.command_coords,
})

PL.RegisterCommand("goto", {'admin'}, function(sPlayer, args)
    local targetCoords = args.playerId.getCoords()
    sPlayer.setCoords(targetCoords)

    PL.Discord.DiscordLogFields("UserActions", "Admin Teleport /goto Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Target Coords", value = targetCoords, inline = true },
    })

end, false, {
    help = Translations.command_goto,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
    },
})

PL.RegisterCommand("bring", {'admin'}, function(sPlayer, args)
    local targetCoords = args.playerId.getCoords()
    local playerCoords = sPlayer.getCoords()
    args.playerId.setCoords(playerCoords)

    PL.Discord.DiscordLogFields("UserActions", "Admin Teleport /bring Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
        { name = "Target Coords", value = targetCoords, inline = true },
    })

end, false, {
    help = Translations.command_bring,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
    },
})

PL.RegisterCommand("freeze", {'admin'}, function(sPlayer, args)
    args.playerId.triggerEvent("primordial_core:client:freezePlayer", "freeze")

    PL.Discord.DiscordLogFields("UserActions", "Admin Freeze /freeze Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
    })

end, true, {
    help = Translations.command_freeze,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
    },
})

PL.RegisterCommand("unfreeze", {'admin'}, function(sPlayer, args)
    args.playerId.triggerEvent("primordial_core:client:freezePlayer", "unfreeze")

    PL.Discord.DiscordLogFields("UserActions", "Admin UnFreeze /unfreeze Triggered!", "pink", {
        { name = "Player", value = sPlayer and sPlayer.name or "Server Console", inline = true },
        { name = "ID", value = sPlayer and sPlayer.source or "Unknown ID", inline = true },
        { name = "Target", value = args.playerId.name, inline = true },
    })

end, true, {
    help = Translations.command_unfreeze,
    validate = true,
    arguments = {
        { name = "playerId", help = Translations.commandgeneric_playerid, type = "player" },
    },
})

PL.RegisterCommand("players", {'admin'}, function()
    local sPlayers = PL.GetExtendedPlayers() -- Returns all sPlayers
    print(("^5%s^2 online player(s)^0"):format(#sPlayers))
    for i = 1, #sPlayers do
        local sPlayer = sPlayers[i]
        print(("^1[^2ID: ^5%s^0 | ^2Name : ^5%s^0 | ^2Group : ^5%s^0 | ^2Identifier : ^5%s^1]^0\n"):format(sPlayer.source, sPlayer.getName(), sPlayer.getGroup(), sPlayer.identifier))
    end
end, true)