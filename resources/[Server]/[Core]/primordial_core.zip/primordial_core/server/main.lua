SetMapName("San Andreas")
SetGameType("Primordial Core")

local oneSyncState = GetConvar("onesync", "off")
local newPlayer = "INSERT INTO `users` SET `accounts` = ?, `identifier` = ?, `group` = ?"
local loadPlayer = "SELECT `accounts`, `job`, `job_grade`, `group`, `position`, `inventory`, `skin`, `loadout`, `metadata`"

if StartingInventoryItems then
    newPlayer = newPlayer .. ", `inventory` = ?"
end

loadPlayer = loadPlayer .. ", `firstname`, `lastname`, `dateofbirth`, `sex`, `height`"
loadPlayer = loadPlayer .. " FROM `users` WHERE identifier = ?"

RegisterNetEvent("primordial_core:server:onPlayerJoined")
AddEventHandler("primordial_core:server:onPlayerJoined", function()
    local _source = source
    while not next(PL.Jobs) do
        Wait(50)
    end

    if not PL.Players[_source] then
        onPlayerJoined(_source)
    end
end)

function onPlayerJoined(playerId)
    local identifier = PL.GetIdentifier(playerId)
    if identifier then
        if PL.GetPlayerFromIdentifier(identifier) then
            DropPlayer(
                playerId,
                ("there was an error loading your character!\nError code: identifier-active-ingame\n\nThis error is caused by a player on this server who has the same identifier as you have. Make sure you are not playing on the same Rockstar account.\n\nYour Rockstar identifier: %s"):format(
                    identifier
                )
            )
        else
            local result = MySQL.scalar.await("SELECT 1 FROM users WHERE identifier = ?", { identifier })
            if result then
                LoadPrimordialPlayer(identifier, playerId, false)
            else
                CreatePrimordialPlayer(identifier, playerId)
            end
        end
    else
        DropPlayer(playerId, "there was an error loading your character!\nError code: identifier-missing-ingame\n\nThe cause of this error is not known, your identifier could not be found. Please come back later or report this problem to the server administration team.")
    end
end

function CreatePrimordialPlayer(identifier, playerId, data)
    local accounts = {}

    for account, money in pairs(StartingAccountMoney) do
        accounts[account] = money
    end

    local defaultGroup = "user"
    if PL.AdminPermissions(playerId) then
        print(("[^2INFO^0] Player ^5%s^0 Has been granted admin permissions via ^5Ace Perms^7."):format(playerId))
        defaultGroup = "admin"
    end

    local parameters = false and { json.encode(accounts), identifier, defaultGroup, data.firstname, data.lastname, data.dateofbirth, data.sex, data.height } or { json.encode(accounts), identifier, defaultGroup }

    if StartingInventoryItems then
        table.insert(parameters, json.encode(StartingInventoryItems))
    end

    MySQL.prepare(newPlayer, parameters, function()
        LoadPrimordialPlayer(identifier, playerId, true)
    end)
end

AddEventHandler("playerConnecting", function(_, _, deferrals)
    deferrals.defer()
    local playerId = source
    local identifier = PL.GetIdentifier(playerId)

    if oneSyncState == "off" or oneSyncState == "legacy" then
        return deferrals.done(("[PL] PL Requires Onesync Infinity to work. This server currently has Onesync set to: %s"):format(oneSyncState))
    end

    if not PL.DatabaseConnected then
        return deferrals.done("[PL] OxMySQL Was Unable To Connect to your database. Please make sure it is turned on and correctly configured in your server.cfg")
    end

    if identifier then
        if PL.GetPlayerFromIdentifier(identifier) then
            return deferrals.done(
                ("[PL] There was an error loading your character!\nError code: identifier-active\n\nThis error is caused by a player on this server who has the same identifier as you have. Make sure you are not playing on the same account.\n\nYour identifier: %s"):format(identifier)
            )
        else
            return deferrals.done()
        end
    else
        return deferrals.done("[PL] There was an error loading your character!\nError code: identifier-missing\n\nThe cause of this error is not known, your identifier could not be found. Please come back later or report this problem to the server administration team.")
    end
end)

function LoadPrimordialPlayer(identifier, playerId, isNew)
    local userData = {
        accounts = {},
        inventory = {},
        loadout = {},
        weight = 0,
        identifier = identifier,
        firstName = "John",
        lastName = "Doe",
        dateofbirth = "01/01/2000",
        height = 120,
        dead = false,
    }

    local result = MySQL.prepare.await(loadPlayer, { identifier })

    -- Accounts
    local accounts = result.accounts
    accounts = (accounts and accounts ~= "") and json.decode(accounts) or {}

    for account, data in pairs(AccountsFramework) do
        data.round = data.round or data.round == nil

        local index = #userData.accounts + 1
        userData.accounts[index] = {
            name = account,
            money = accounts[account] or StartingAccountMoney[account] or 0,
            label = data.label,
            round = data.round,
            index = index,
        }
    end

    -- Job
    local job, grade = result.job, tostring(result.job_grade)

    if not PL.DoesJobExist(job, grade) then
        print(("[^3WARNING^7] Ignoring invalid job for ^5%s^7 [job: ^5%s^7, grade: ^5%s^7]"):format(identifier, job, grade))
        job, grade = "unemployed", "0"
    end

    local jobObject, gradeObject = PL.Jobs[job], PL.Jobs[job].grades[grade]

    userData.job = {
        id = jobObject.id,
        name = jobObject.name,
        label = jobObject.label,

        grade = tonumber(grade),
        grade_name = gradeObject.name,
        grade_label = gradeObject.label,
        grade_salary = gradeObject.salary,

        skin_male = gradeObject.skin_male and json.decode(gradeObject.skin_male) or {},
        skin_female = gradeObject.skin_female and json.decode(gradeObject.skin_female) or {},
    }

    -- Inventory
    if result.inventory and result.inventory ~= "" then
        userData.inventory = json.decode(result.inventory)
    end

    -- Group
    if result.group then
        if result.group == "superadmin" then
            userData.group = "admin"
            print("[^3WARNING^7] ^5Superadmin^7 detected, setting group to ^5admin^7")
        else
            userData.group = result.group
        end
    else
        userData.group = "user"
    end

    -- Position
    userData.coords = json.decode(result.position) or DefaultSpawnPosition[PL.Math.Random(1,#DefaultSpawnPosition)]

    -- Skin
    userData.skin = (result.skin and result.skin ~= "") and json.decode(result.skin) or { sex = userData.sex == "f" and 1 or 0 }

    -- Metadata
    userData.metadata = (result.metadata and result.metadata ~= "") and json.decode(result.metadata) or {}

    -- sPlayer Creation
    local sPlayer = CreateStudioPlayer(playerId, identifier, userData.group, userData.accounts, userData.inventory, userData.weight, userData.job, userData.loadout, GetPlayerName(playerId), userData.coords, userData.metadata)
    PL.Players[playerId] = sPlayer
    PL.playersByIdentifier[identifier] = sPlayer

    -- Identity
    if result.firstname and result.firstname ~= "" then
        userData.firstName = result.firstname
        userData.lastName = result.lastname

        sPlayer.set("firstName", result.firstname)
        sPlayer.set("lastName", result.lastname)
        sPlayer.setName(("%s %s"):format(result.firstname, result.lastname))

        if result.dateofbirth then
            userData.dateofbirth = result.dateofbirth
            sPlayer.set("dateofbirth", result.dateofbirth)
        end
        if result.sex then
            userData.sex = result.sex
            sPlayer.set("sex", result.sex)
        end
        if result.height then
            userData.height = result.height
            sPlayer.set("height", result.height)
        end
    end

    TriggerEvent("primordial_core:playerLoaded", playerId, sPlayer, isNew)
    userData.money = sPlayer.getMoney()
    userData.maxWeight = sPlayer.getMaxWeight()
    sPlayer.triggerEvent("primordial_core:playerLoaded", userData, isNew, userData.skin)

    exports.ox_inventory:setPlayerInventory(sPlayer, userData.inventory)
    if isNew then
        local shared = json.decode(GetConvar("inventory:accounts", '["money"]'))

        for i = 1, #shared do
            local name = shared[i]
            local account = StartingAccountMoney[name]
            if account then
                exports.ox_inventory:AddItem(playerId, name, account)
            end
        end
    end
    sPlayer.triggerEvent("primordial_core:client:registerSuggestions", PL.RegisteredCommands)
    print(('[^2INFO^0] Player ^5"%s"^0 has connected to the server. ID: ^5%s^7'):format(sPlayer.getName(), playerId))
end

AddEventHandler("chatMessage", function(playerId, _, message)
    local sPlayer = PL.GetPlayerFromId(playerId)
    if message:sub(1, 1) == "/" and playerId > 0 then
        CancelEvent()
        local commandName = message:sub(1):gmatch("%w+")()
        TriggerClientEvent('ox_lib:notify', sPlayer.source, {
            titlle = Translations.commanderror_invalidcommand:format(commandName),
            type = 'error',
        })
    end
end)

AddEventHandler("playerDropped", function(reason)
    local playerId = source
    local sPlayer = PL.GetPlayerFromId(playerId)

    if sPlayer then
        TriggerEvent("primordial_core:playerDropped", playerId, reason)
        local job = sPlayer.getJob().name
        local currentJob = PL.JobsPlayerCount[job]
        PL.JobsPlayerCount[job] = ((currentJob and currentJob > 0) and currentJob or 1) - 1
        GlobalState[("%s:count"):format(job)] = PL.JobsPlayerCount[job]
        PL.playersByIdentifier[sPlayer.identifier] = nil
        PL.SavePlayer(sPlayer, function()
            PL.Players[playerId] = nil
        end)
    end
end)

AddEventHandler("primordial_core:playerLoaded", function(_, sPlayer)
    local job = sPlayer.getJob().name
    local jobKey = ("%s:count"):format(job)

    PL.JobsPlayerCount[job] = (PL.JobsPlayerCount[job] or 0) + 1
    GlobalState[jobKey] = PL.JobsPlayerCount[job]
end)

AddEventHandler("primordial_core:setJob", function(_, job, lastJob)
    local lastJobKey = ("%s:count"):format(lastJob.name)
    local jobKey = ("%s:count"):format(job.name)
    local currentLastJob = PL.JobsPlayerCount[lastJob.name]

    PL.JobsPlayerCount[lastJob.name] = ((currentLastJob and currentLastJob > 0) and currentLastJob or 1) - 1
    PL.JobsPlayerCount[job.name] = (PL.JobsPlayerCount[job.name] or 0) + 1

    GlobalState[lastJobKey] = PL.JobsPlayerCount[lastJob.name]
    GlobalState[jobKey] = PL.JobsPlayerCount[job.name]
end)

AddEventHandler("primordial_core:playerLogout", function(playerId, cb)
    local sPlayer = PL.GetPlayerFromId(playerId)
    if sPlayer then
        TriggerEvent("primordial_core:playerDropped", playerId)

        PL.playersByIdentifier[sPlayer.identifier] = nil
        PL.SavePlayer(sPlayer, function()
            PL.Players[playerId] = nil
            if cb then
                cb()
            end
        end)
    end
    TriggerClientEvent("primordial_core:onPlayerLogout", playerId)
end)

lib.callback.register('primordial_core:getPlayerData', function(source)
    local sPlayer = PL.GetPlayerFromId(source)

    return{
        identifier = sPlayer.identifier,
        accounts = sPlayer.getAccounts(),
        inventory = sPlayer.getInventory(),
        job = sPlayer.getJob(),
        loadout = sPlayer.getLoadout(),
        money = sPlayer.getMoney(),
        position = sPlayer.getCoords(true),
        metadata = sPlayer.getMeta(),
    }
end)

lib.callback.register('primordial_core:isUserAdmin', function(source)
    return PL.AdminPermissions(source)
end)

lib.callback.register('primordial_core:getGameBuild', function()
    return tonumber(GetConvar("sv_enforceGameBuild", 1604))
end)

lib.callback.register('primordial_core:getOtherPlayerData', function(target)
    local sPlayer = PL.GetPlayerFromId(target)

    return {
        identifier = sPlayer.identifier,
        accounts = sPlayer.getAccounts(),
        inventory = sPlayer.getInventory(),
        job = sPlayer.getJob(),
        loadout = sPlayer.getLoadout(),
        money = sPlayer.getMoney(),
        position = sPlayer.getCoords(true),
        metadata = sPlayer.getMeta(),
    }
end)

lib.callback.register('primordial_core:getPlayerNames', function(source, players)
    players[source] = nil

    for playerId, _ in pairs(players) do
        local sPlayer = PL.GetPlayerFromId(playerId)

        if sPlayer then
            players[playerId] = sPlayer.getName()
        else
            players[playerId] = nil
        end
    end

    return players
end)

lib.callback.register('primordial_core:spawnVehicle', function(source, vehData)
    local ped = GetPlayerPed(source)
    PL.Vehicle.SpawnServerVehicle(vehData.model or `ADDER`, vehData.coords or GetEntityCoords(ped), vehData.coords.w or 0.0, vehData.props or {}, function(id)
        if vehData.warp then
            local vehicle = NetworkGetEntityFromNetworkId(id)
            local timeout = 0
            while GetVehiclePedIsIn(ped) ~= vehicle and timeout <= 15 do
                Wait(0)
                TaskWarpPedIntoVehicle(ped, vehicle, -1)
                timeout += 1
            end
        end
        return id
    end)
end)

AddEventHandler("txAdmin:events:scheduledRestart", function(eventData)
    if eventData.secondsRemaining == 60 then
        CreateThread(function()
            Wait(50000)
            PL.SavePlayers()
        end)
    end
end)

AddEventHandler("txAdmin:events:serverShuttingDown", function()
    PL.SavePlayers()
end)

local usersStarted = {}
MySQL.ready(function()
    local p = promise.new()
    MySQL.query('SELECT * FROM users', function(result)
        usersStarted = result
        p:resolve(true)
    end)
    Citizen.Await(p)
    PL.Print.Info(('%s Users Loaded'):format(#usersStarted))
end)