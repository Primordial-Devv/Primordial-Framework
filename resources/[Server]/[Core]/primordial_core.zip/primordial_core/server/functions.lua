local function PlayerHasPermissions(source, group)
    local player = PL.GetPlayerFromId(source)
    if not player then return end
    if player.getGroup() ~= group then
        return false
    else
        return true
    end
end

function PL.RegisterCommand(commandName, groups, callbackFunction, allowConsole, suggestion)
    if type(commandName) == "table" then
        for _, v in ipairs(commandName) do
            PL.RegisterCommand(v, groups, callbackFunction, allowConsole, suggestion)
        end
        return
    end

    if PL.RegisteredCommands[commandName] then
        PL.Print.Warning(('Command "%s" already registered, overriding command'):format(commandName))
        if PL.RegisteredCommands[commandName].suggestion then
            TriggerClientEvent("chat:removeSuggestion", -1, ("/%s"):format(commandName))
        end
    end

    if suggestion then
        suggestion.arguments = suggestion.arguments or {}
        suggestion.help = suggestion.help or ""
        TriggerClientEvent("chat:addSuggestion", -1, ("/%s"):format(commandName), suggestion.help, suggestion.arguments)
    end

    PL.RegisteredCommands[commandName] = {
        groups = groups,
        callbackFunction = callbackFunction,
        allowConsole = allowConsole,
        suggestion = suggestion
    }

    RegisterCommand(commandName, function(source, args)
        local command = PL.RegisteredCommands[commandName]

        local function handleError(msg)
            if source == 0 then
                PL.Print.Error(msg)
            else
                lib.notify(source, {
                    title = msg;
                    type = "error";
                })
            end
        end

        if not command.allowConsole and source == 0 then
            handleError(('The command "%s" cannot be used from the console'):format(commandName))
            return
        end

        local hasGroupPermissions = false
        if source == 0 then
            hasGroupPermissions = command.allowConsole
        elseif command.groups then
            for _, groups in ipairs(command.groups) do
                if PlayerHasPermissions(source, groups) then
                    hasGroupPermissions = true
                    break
                end
            end
        end

        if not hasGroupPermissions then
            handleError(('Player "%s" does not have permission to use the command "%s"'):format(source, commandName))
            return
        end
        -- if not PL.AdminPermissions(source) then
        --     PL.Print.Error(('Player "%s" does not have permission to use the command "%s"'):format(source, commandName))
        --     return
        -- end

        local sPlayer = PL.Players[source]

        if command.suggestion then
            if command.suggestion.validate then
                if #args ~= #command.suggestion.arguments then
                    handleError((Translations.commanderror_argumentmismatch):format(#args, #command.suggestion.arguments))
                end
            end

            if command.suggestion.arguments then
                local newArgs = {}

                for k, v in ipairs(command.suggestion.arguments) do
                    local arg = args[k]
                    if v.type then
                        if v.type == "number" then
                            local newArg = tonumber(arg)

                            if newArg then
                                newArgs[v.name] = newArg
                            else
                                handleError((Translations.commanderror_argumentmismatch_number):format(k))
                                return
                            end
                        elseif v.type == "player" or v.type == "playerId" then
                            local targetPlayer = tonumber(arg) or (arg == "me" and source)

                            -- if arg == "me" then
                            --     targetPlayer = source
                            -- end

                            if targetPlayer then
                                local xTargetPlayer = PL.GetPlayerFromId(targetPlayer)

                                if xTargetPlayer then
                                    newArgs[v.name] = (v.type == 'player') and xTargetPlayer or targetPlayer
                                else
                                    handleError(Translations.commanderror_invalidplayerid)
                                    return
                                end
                            else
                                handleError((Translations.commanderror_argumentmismatch_number):format(k))
                                return
                            end
                        elseif v.type == "string" then
                            local newArg = tonumber(arg)
                            if not newArg then
                                newArgs[v.name] = arg
                            else
                                handleError((Translations.commanderror_argumentmismatch_string):format(k))
                                return
                            end
                        elseif v.type == "item" then
                            if PL.Items[arg] then
                                newArgs[v.name] = arg
                            else
                                handleError(Translations.commanderror_invaliditem)
                                return
                            end
                        elseif v.type == "any" then
                            newArgs[v.name] = arg
                        elseif v.type == "merge" then
                            -- local length = 0
                            -- for i = 1, k - 1 do
                            --     length = length + string.len(args[i]) + 1
                            -- end
                            -- local merge = table.concat(args, " ")

                            -- newArgs[v.name] = string.sub(merge, length)
                            newArgs[v.name] = table.concat(args, " ", k)
                            break
                        elseif v.type == "coordinate" then
                            local coord = tonumber(arg:match("(-?%d+%.?%d*)"))
                            if not coord then
                                handleError((Translations.commanderror_argumentmismatch_number):format(k))
                                return
                            else
                                newArgs[v.name] = coord
                            end
                        end
                    end
                end
                args = newArgs
            end
        end

        callbackFunction(sPlayer or false, args, function(msg)
            if source == 0 then
                PL.Print.Warning(msg)
            else
                lib.notify(sPlayer.source, {
                    title = msg;
                    type = "info";
                })
            end
        end)
    end, true)
end

local function updateHealthAndArmorInMetadata(sPlayer)
    local ped = GetPlayerPed(sPlayer.source)
    sPlayer.setMeta("health", GetEntityHealth(ped))
    sPlayer.setMeta("armor", GetPedArmour(ped))
end

function PL.SavePlayer(sPlayer, cb)
    if not sPlayer.spawned then
        return cb and cb()
    end

    updateHealthAndArmorInMetadata(sPlayer)
    local parameters <const> = {
        json.encode(sPlayer.getAccounts(true)),
        sPlayer.job.name,
        sPlayer.job.grade,
        sPlayer.group,
        json.encode(sPlayer.getCoords()),
        json.encode(sPlayer.getInventory(true)),
        json.encode(sPlayer.getLoadout(true)),
        json.encode(sPlayer.getMeta()),
        sPlayer.identifier,
    }

    MySQL.prepare(
        "UPDATE `users` SET `accounts` = ?, `job` = ?, `job_grade` = ?, `group` = ?, `position` = ?, `inventory` = ?, `loadout` = ?, `metadata` = ? WHERE `identifier` = ?",
        parameters,
        function(affectedRows)
            if affectedRows == 1 then
                print(('[^2INFO^7] Saved player ^5"%s^7"'):format(sPlayer.name))
            end
            if cb then
                cb()
            end
        end
    )
end

function PL.SavePlayers(cb)
    local sPlayers <const> = PL.Players
    if not next(sPlayers) then
        return
    end

    local startTime <const> = os.time()
    local parameters = {}

    for _, sPlayer in pairs(PL.Players) do
        updateHealthAndArmorInMetadata(sPlayer)
        parameters[#parameters + 1] = {
            json.encode(sPlayer.getAccounts(true)),
            sPlayer.job.name,
            sPlayer.job.grade,
            sPlayer.group,
            json.encode(sPlayer.getCoords()),
            json.encode(sPlayer.getInventory(true)),
            json.encode(sPlayer.getLoadout(true)),
            json.encode(sPlayer.getMeta()),
            sPlayer.identifier,
        }
    end

    MySQL.prepare(
        "UPDATE `users` SET `accounts` = ?, `job` = ?, `job_grade` = ?, `group` = ?, `position` = ?, `inventory` = ?, `loadout` = ?, `metadata` = ? WHERE `identifier` = ?",
        parameters,
        function(results)
            if not results then
                return
            end

            if type(cb) == "function" then
                return cb()
            end

            print(("[^2INFO^7] Saved ^5%s^7 %s over ^5%s^7 ms"):format(#parameters, #parameters > 1 and "players" or "player", PL.Math.Round((os.time() - startTime) / 1000000, 2)))
        end
    )
end

PL.GetPlayers = GetPlayers

local function checkTable(key, val, player, sPlayers)
    for valIndex = 1, #val do
        local value = val[valIndex]
        if not sPlayers[value] then
            sPlayers[value] = {}
        end

        if (key == "job" and player.job.name == value) or player[key] == value then
            sPlayers[value][#sPlayers[value] + 1] = player
        end
    end
end

function PL.GetExtendedPlayers(key, val)
    local sPlayers = {}
    if type(val) == "table" then
        for _, v in pairs(PL.Players) do
            checkTable(key, val, v, sPlayers)
        end
    else
        for _, v in pairs(PL.Players) do
            if key then
                if (key == "job" and v.job.name == val) or v[key] == val then
                    sPlayers[#sPlayers + 1] = v
                end
            else
                sPlayers[#sPlayers + 1] = v
            end
        end
    end

    return sPlayers
end

function PL.GetNumPlayers(key, val)
    if not key then
        return #GetPlayers()
    end

    if type(val) == "table" then
        local numPlayers = {}
        if key == "job" then
            for _, v in ipairs(val) do
                numPlayers[v] = (PL.JobsPlayerCount[v] or 0)
            end
            return numPlayers
        end

        local filteredPlayers = PL.GetExtendedPlayers(key, val)
        for i, v in pairs(filteredPlayers) do
            numPlayers[i] = (#v or 0)
        end
        return numPlayers
    end

    if key == "job" then
        return (PL.JobsPlayerCount[val] or 0)
    end

    return #PL.GetExtendedPlayers(key, val)
end

function PL.GetPlayerFromId(source)
    return PL.Players[tonumber(source)]
end

function PL.GetPlayerFromIdentifier(identifier)
    return PL.playersByIdentifier[identifier]
end

function PL.GetIdentifier(playerId)
    local fxDk = GetConvarInt("sv_fxdkMode", 0)
    if fxDk == 1 then
        return "PL-DEBUG-LICENCE"
    end

    local identifier = GetPlayerIdentifierByType(playerId, "license")
    return identifier and identifier:gsub("license:", "")
end

---@param model string|number
---@param player number playerId
---@param cb function

function PL.GetVehicleType(model, player, cb)
    model = type(model) == "string" and joaat(model) or model

    if PL.vehicleTypesByModel[model] then
        return cb(PL.vehicleTypesByModel[model])
    end

    local vehicleType = lib.callback.await('primordial_core:client:GetVehicleType', player, model)
    PL.vehicleTypesByModel[model] = vehicleType
    cb(vehicleType)
end

function PL.RefreshJobs()
    local Jobs = {}
    local jobs = MySQL.query.await("SELECT * FROM jobs")

    for _, v in ipairs(jobs) do
        Jobs[v.name] = v
        Jobs[v.name].grades = {}
    end

    local jobGrades = MySQL.query.await("SELECT * FROM job_grades")

    for _, v in ipairs(jobGrades) do
        if Jobs[v.job_name] then
            Jobs[v.job_name].grades[tostring(v.grade)] = v
        else
            print(('[^3WARNING^7] Ignoring job grades for ^5"%s"^0 due to missing job'):format(v.job_name))
        end
    end

    for _, v in pairs(Jobs) do
        if PL.Table.SizeOf(v.grades) == 0 then
            Jobs[v.name] = nil
            print(('[^3WARNING^7] Ignoring job ^5"%s"^0 due to no job grades found'):format(v.name))
        end
    end

    if not Jobs then
        -- Fallback data, if no jobs exist
        PL.Jobs["unemployed"] = { label = "Unemployed", grades = { ["0"] = { grade = 0, label = "Unemployed", salary = 200, skin_male = {}, skin_female = {} } } }
    else
        PL.Jobs = Jobs
    end
end

function PL.RegisterUsableItem(item, cb)
    PL.UsableItemsCallbacks[item] = cb
end

function PL.UseItem(source, item, ...)
    if PL.Items[item] then
        local itemCallback = PL.UsableItemsCallbacks[item]

        if itemCallback then
            local success, result = pcall(itemCallback, source, item, ...)

            if not success then
                return result and print(result) or print(('[^3WARNING^7] An error occured when using item ^5"%s"^7! This was not caused by PL.'):format(item))
            end
        end
    else
        print(('[^3WARNING^7] Item ^5"%s"^7 was used but does not exist!'):format(item))
    end
end

function PL.GetItemLabel(item)
    item = exports.ox_inventory:Items(item)
    if item then
        return item.label
    end

    if PL.Items[item] then
        return PL.Items[item].label
    else
        print(("[^3WARNING^7] Attemting to get invalid Item -> ^5%s^7"):format(item))
    end
end

function PL.GetJobs()
    return PL.Jobs
end

function PL.GetUsableItems()
    local Usables = {}
    for k in pairs(PL.UsableItemsCallbacks) do
        Usables[k] = true
    end
    return Usables
end

function PL.DoesJobExist(job, grade)
    return (PL.Jobs[job] and PL.Jobs[job].grades[tostring(grade)] ~= nil) or false
end

function PL.AdminPermissions(source)
    if source == 0 then
        return true
    end

    local player = PL.Players[source]
    if not player then
        PL.Print.Error('Cannot find the player object for the source provided.')
        return false
    end

    local playerGroup = player.getGroup()

    if PermissionsGroups[playerGroup] then
        return true
    else
        return false
    end
end