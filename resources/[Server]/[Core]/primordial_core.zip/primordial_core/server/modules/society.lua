local RegisteredSocieties = {}
local SocietyAccounts = {}

function GetSociety(name)
    return RegisteredSocieties[name]
end
exports("GetSociety", GetSociety)

function registerSociety(name, label, registration_number, initialAmount)
    if RegisteredSocieties[name] then
        print(('[^3WARNING^7] society already registered, name: ^5%s^7'):format(name))
        return
    end

    local society = Society:new(nil, name, label, registration_number, initialAmount)
    RegisteredSocieties[name] = society

    AddSocietyAccount(society, initialAmount)

    print(('[^2INFO^7] Society registered, name: ^5%s^7, label: ^5%s^7'):format(name, label))
end

--AddEventHandler('primordial_core:server:registerSociety', registerSociety)
--exports("registerSociety", registerSociety)

--AddEventHandler('onResourceStart', function(resourceName)
--    if resourceName ~= GetCurrentResourceName() then
--        return
--    end
--    local result, error = MySQL.prepare.await('SELECT s.id, s.name, s.label, s.registration_number, a.balance FROM society s JOIN society_account a ON s.id = a.society_id')
--
--    if error then
--        print(('[^3WARNING^7] Failed to load societies: %s'):format(error))
--        return
--    end
--
--    for i = 1, #result do
--        local societyData = result[i]
--        local society = Society:new(societyData.id, societyData.name, societyData.label, societyData.registration_number, societyData.balance)
--
--        RegisteredSocieties[societyData.name] = society
--        SocietyAccounts[societyData.name] = society
--    end
--
--    print(('[^2INFO^7] Loaded %d societies'):format(#result))
--end)

AddEventHandler('primordial_core:server:getSocieties', function(cb)
    cb(RegisteredSocieties)
end)

AddEventHandler('primordial_core:server:getSociety', function(name, cb)
    cb(GetSociety(name))
end)

RegisterServerEvent('primordial_core:server:checkSocietyBalance')
AddEventHandler('primordial_core:server:checkSocietyBalance', function(societyName)
    local sPlayer = PL.GetPlayerFromId(source)
    local society = GetSociety(societyName)

    if not society then
        print(('primordial_core_society: %s attempted to check balance of non-existing society - %s'):format(sPlayer.identifier, societyName))
        return
    end

    if sPlayer.job.name ~= society.name then
        print(('primordial_core_society: %s attempted to call checkSocietyBalance for society - %s!'):format(sPlayer.identifier, society.name))
        return
    end

    lib.notify(sPlayer.source, {
        title = Translations.check_balance:format(PL.Math.GroupDigits(society:getBalance())),
        type = 'info',
    })
end)

RegisterServerEvent('primordial_core:server:withdrawMoney')
AddEventHandler('primordial_core:server:withdrawMoney', function(societyName, amount)
    local sPlayer = PL.GetPlayerFromId(source)
    local society = GetSociety(societyName)

    if not society then
        print(('[^3WARNING^7] Player %s attempted to withdraw from non-existing society - %s!'):format(sPlayer.identifier, societyName))
        return
    end

    if sPlayer.job.name ~= society.name then
        print(('[^3WARNING^7] Player %s attempted to withdraw from society - %s!'):format(sPlayer.identifier, society.name))
        return
    end

    amount = tonumber(amount)
    if not amount or amount <= 0 then
        lib.notify(sPlayer.source, {
            title = Translations.invalid_amount,
            type = 'error',
        })
        return
    end

    local success, message = society:removeMoney(amount)
    if success then
        sPlayer.addMoney(amount, Translations.money_add_reason)
        lib.notify(sPlayer.source, {
            title = Translations.have_withdrawn:format(PL.Math.GroupDigits(amount)),
            type = 'info',
        })
    else
        lib.notify(sPlayer.source, {
            title = message,
            type = 'error',
        })
    end
end)

RegisterServerEvent('primordial_core:server:depositMoney')
AddEventHandler('primordial_core:server:depositMoney', function(societyName, amount)
    local sPlayer = PL.GetPlayerFromId(source)
    local society = GetSociety(societyName)

    if not society then
        print(('[^3WARNING^7] Player %s attempted to deposit to non-existing society - %s!'):format(sPlayer.identifier, societyName))
        return
    end

    if sPlayer.job.name ~= society.name then
        print(('[^3WARNING^7] Player %s attempted to deposit to society - %s!'):format(sPlayer.identifier, society.name))
        return
    end

    amount = tonumber(amount)
    if not amount or amount <= 0 then
        lib.notify(sPlayer.source, {
            title = Translations.invalid_amount,
            type = 'error',
        })
        return
    end

    if sPlayer.getMoney() < amount then
        lib.notify(sPlayer.source, {
            title = Translations.not_enough_money,
            type = 'error',
        })
        return
    end

    local success, message = society:addMoney(amount)
    if success then
        sPlayer.removeMoney(amount, Translations.money_remove_reason)
        lib.notify(sPlayer.source, {
            title = Translations.have_deposited:format(PL.Math.GroupDigits(amount)),
            type = 'info',
        })
    else
        lib.notify(sPlayer.source, {
            title = message,
            type = 'error',
        })
    end
end)

function AddSocietyAccount(society, initialAmount)
    if not society or not society.name then
        print(('[^3WARNING^7] Attempted to add society account with invalid society: %s'):format(society and society.name or 'nil'))
        return
    end

    if SocietyAccounts[society.name] ~= nil then
        return SocietyAccounts[society.name]
    end

    local iban = 'IBAN_' .. society.name
    local account, error = MySQL.prepare.await('INSERT INTO society_account (society_id, balance, iban) VALUES (?, ?, ?)', {society.id, (initialAmount or 0), iban})
    if error then
        print(('[^3WARNING^7] Failed to add society account: %s'):format(error))
        return
    end

    if not account then
        print(('[^3WARNING^7] Failed to add society account for society: %s'):format(society.name))
        return
    end

    SocietyAccounts[society.name] = society
    return society
end

RegisterServerEvent('primordial_core:server:refreshAccounts')
AddEventHandler('primordial_core:server:refreshAccounts', function()
    local result, error = MySQL.prepare.await('SELECT * FROM society_account')

    if error then
        print(('[^3WARNING^7] Failed to refresh society accounts: %s'):format(error))
        return
    end

    for i = 1, #result do
        local account = result[i]
        local balanceResult = account.balance
        local societyAccount = GetSociety(account.name)

        if societyAccount then
            societyAccount.account = balanceResult
            societyAccount[account.name] = societyAccount
        end
    end
end)

lib.callback.register('primordial_core:server:getEmployees', function(source, societyName)
    local society = GetSociety(societyName)
    if not society then
        print(('[^3WARNING^7] Player %s attempted to get employees from non-existing society - %s!'):format(source, societyName))
        return {}
    end

    local success, error = society:loadEmployees()
    if not success then
        print(('[^3WARNING^7] Failed to load employees for society - %s: %s'):format(societyName, error))
        return {}
    end

    return society.employees
end)

lib.callback.register('primordial_core:server:setJob', function(source, identifier, job, grade, actionType)
    local sPlayer = PL.GetPlayerFromId(source)
    local isBoss = sPlayer.job and sPlayer.job.grade_name and SocietyBossGrades[sPlayer.job.grade_name]
    local sTarget = PL.GetPlayerFromIdentifier(identifier)

    if sPlayer.identifier == identifier then
        print(('[^3WARNING^7] Player %s attempted to change their own job!'):format(source))
        return false
    end

    if not isBoss then
        print(('[^3WARNING^7] Player %s attempted to set job for Player %s!'):format(source, sTarget.source and sTarget.source or 'unknown'))
        return false
    end

    if not sTarget then
        local updateResult, error = MySQL.prepare.await('UPDATE users SET job = ?, job_grade = ? WHERE identifier = ?', {job, grade, identifier})
        if not updateResult then
            print(('[^3WARNING^7] Failed to update job for Player %s: %s'):format(identifier, error))
            return false
        end
        return true
    end

    sTarget.setJob(job, grade)

    if actionType == 'hire' then
        lib.notify(sTarget.source, {title = Translations.you_have_been_hired:format(job), type = 'info'})
        lib.notify(sPlayer.source, {title = Translations.you_have_hired:format(sTarget.getName()), type = 'info'})
    elseif actionType == 'promote' then
        lib.notify(sTarget.source, {title = Translations.you_have_been_promoted, type = 'info'})
        lib.notify(sPlayer.source, {title = Translations.you_have_promoted:format(sTarget.getName(), sTarget.getJob().label), type = 'info'})
    elseif actionType == 'fire' then
        lib.notify(sTarget.source, {title = Translations.you_have_been_fired:format(sTarget.getJob().label), type = 'info'})
        lib.notify(sPlayer.source, {title = Translations.you_have_fired:format(sTarget.getName()), type = 'info'})
    end
    return true
end)