local RegisteredJobs = {}

local function isJobInSociety(jobName)
    local result, error = MySQL.query.await('SELECT * FROM society WHERE name = ?', { jobName })
    if error then
        print(('[^3WARNING^7] Error checking job in society: %s'):format(error))
        return false
    end
    return #result > 0
end

local function addMissingJobsToSociety()
    for jobName, jobData in pairs(RegisteredJobs) do
        if not isJobInSociety(jobName) then
            local registrationNumber = PL.Print.GetRandomString(15) -- Utilise ta fonction pour générer un numéro d'enregistrement
            MySQL.prepare.await('INSERT INTO society (name, label, registration_number) VALUES (?, ?, ?)',
                { jobName, jobData.label, registrationNumber })
            print(('[^2INFO^7] Job %s added to society with registration_number: %s'):format(jobName, registrationNumber))
        else
            print(('[^2INFO^7] Job %s already exists in society, skipping...'):format(jobName))
        end
    end
end

local function fetchAndStoreJobs()
    local jobs, error = MySQL.query.await("SELECT name, label FROM jobs")

    if error then
        print(('[^3WARNING^7] Error fetching jobs: %s'):format(error))
        return
    end

    for _, job in ipairs(jobs) do
        if not RegisteredJobs[job.name] then
            RegisteredJobs[job.name] = {
                label = job.label,
            }
            print(('[^2INFO^7] Job %s added to RegisteredJobs table'):format(job.name))
        else
            print(('[^2INFO^7] Job %s already exists in RegisteredJobs, skipping...'):format(job.name))
        end
    end
end

local function doesTableExist(tableName)
    local result, error = MySQL.query.await("SHOW TABLES LIKE ?", { tableName })
    if error then
        print(('[^3WARNING^7] Error checking table existence: %s'):format(error))
        return false
    end

    return #result > 0
end

local function createSocietyMigrations()
    if not doesTableExist('society') then
        print('[^2INFO^7] Creating `society` table...')
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS society (
                id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(60) NOT NULL UNIQUE,
                label VARCHAR(100) NOT NULL,
                registration_number VARCHAR(60) NOT NULL UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ]])
        print('[^2INFO^7] Table `society` created.')
    end

    if not doesTableExist('society_account') then
        print('[^2INFO^7] Creating `society_account` table...')
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS society_account (
                id INT(11) NOT NULL AUTO_INCREMENT,
                society_id INT(11) NOT NULL,
                balance INT(11) NOT NULL DEFAULT 0,
                iban VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY iban (iban),
                KEY society_id (society_id),
                CONSTRAINT society_account_ibfk_1 FOREIGN KEY (society_id) REFERENCES society (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ]])
        print('[^2INFO^7] Table `society_account` created.')
    end

    if not doesTableExist('society_employee') then
        print('[^2INFO^7] Creating `society_employee` table...')
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS society_employee (
                id INT(11) NOT NULL AUTO_INCREMENT,
                identifier VARCHAR(50) NOT NULL,
                grade INT(11) NOT NULL DEFAULT 0,
                society_id INT(11) NOT NULL,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY society_id (societyS_id),
                CONSTRAINT society_employee_ibfk_1 FOREIGN KEY (society_id) REFERENCES society (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ]])
        print('[^2INFO^7] Table `society_employee` created.')
    end
end

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        print('[^2INFO^7] Checking and creating society tables if necessary...')
        createSocietyMigrations()
        print('[^2INFO^7] Fetching jobs and storing them in Lua table...')
        fetchAndStoreJobs()
        print('[^2INFO^7] Adding missing jobs to society...')
        addMissingJobsToSociety()
        PL.Print.Debug(json.encode(RegisteredJobs, { indent = true }))
    end
end)