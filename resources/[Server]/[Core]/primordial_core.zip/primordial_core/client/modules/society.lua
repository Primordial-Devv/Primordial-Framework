local function OpenBossMenu(society)
    local societyElements = {}

    societyElements[#societyElements + 1] = {
        title = 'Manage Society Account',
        description = 'Manage the society account',
        icon = 'fa-solid fa-file-invoice-dollar',
        onSelect = function()
            PL.Print.Debug('Manage Society Account')
        end
    }

    societyElements[#societyElements + 1] = {
        title = 'Manage Employees',
        description = 'Manage the society employees',
        icon = 'fa-solid fa-user-tie',
        onSelect = function()
            PL.Print.Debug('Manage Employees')
        end
    }

    lib.registerContext({
        id = 'primordial_core_society_boss',
        title = society.name .. ' Boss Menu',
        options = societyElements,
    })

    lib.showContext('primordial_core_society_boss')
end

RegisterNetEvent('primordial_core:client:openBossMenu', function(society)
    OpenBossMenu(society, options)
end)

--lib.callback.register('primordial_core:client:openBossMenu', function(society, options)
--    OpenBossMenu(society, options)
--end)