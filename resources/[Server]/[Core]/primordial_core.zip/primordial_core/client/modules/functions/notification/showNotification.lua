-- Show a notification custom exports
---@param title string The title of the notification
---@param message string The message to put in notification
---@param level string The level of the notification
---@param duration number The duration of the notification
function PL.Notification.ShowClientNotification(title, message, level, duration)
    -- PUT NOTIFICATION EXPORT
end

return PL.Notification.ShowClientNotification