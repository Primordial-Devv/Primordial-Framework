CreateThread(function()
    while true do
        Wait(100)

        if NetworkIsPlayerActive(PlayerId()) then
            exports.spawnmanager:setAutoSpawn(false)
            DoScreenFadeOut(0)
            Wait(500)
            TriggerServerEvent("primordial_core:server:onPlayerJoined")
            break
        end
    end
end)

function PL.SpawnPlayer(skin, coords, cb)
    local p = promise.new()
    TriggerEvent("skinchanger:loadSkin", skin, function()
        p:resolve()
    end)
    Citizen.Await(p)

    local playerPed = PlayerPedId()
    FreezeEntityPosition(playerPed, true)
    SetEntityCoordsNoOffset(playerPed, coords.x, coords.y, coords.z, false, false, false, true)
    SetEntityHeading(playerPed, coords.heading)
    while not HasCollisionLoadedAroundEntity(playerPed) do
        Wait(0)
    end
    FreezeEntityPosition(playerPed, false)
    NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, coords.heading, true, true, false)
    TriggerEvent('playerSpawned', coords)
    cb()
end

RegisterNetEvent("primordial_core:playerLoaded")
AddEventHandler("primordial_core:playerLoaded", function(sPlayer, _, skin)
    PL.PlayerData = sPlayer

    PL.SpawnPlayer(skin, PL.PlayerData.coords, function()
        TriggerEvent("primordial_core:onPlayerSpawn")
        TriggerEvent("primordial_core:client:restoreLoadout")
        TriggerServerEvent("primordial_core:onPlayerSpawn")
        TriggerEvent("primordial_core:client:loadingScreenOff")
        ShutdownLoadingScreen()
        ShutdownLoadingScreenNui()
    end)

    while not DoesEntityExist(PL.PlayerData.ped) do
        Wait(20)
    end

    PL.PlayerLoaded = true

    local metadata = PL.PlayerData.metadata

    if metadata.health then
        SetEntityHealth(PL.PlayerData.ped, metadata.health)
    end

    if metadata.armor and metadata.armor > 0 then
        SetPedArmour(PL.PlayerData.ped, metadata.armor)
    end

    local timer = GetGameTimer()
    while not HaveAllStreamingRequestsCompleted(PL.PlayerData.ped) and (GetGameTimer() - timer) < 2000 do
        Wait(0)
    end

    -- Enable PVP between players
    SetCanAttackFriendly(PL.PlayerData.ped, true, false)
    NetworkSetFriendlyFireOption(true)

    local playerId = PlayerId()

    -- Disable NPC Drops
    local weaponPickups = { `PICKUP_WEAPON_CARBINERIFLE`, `PICKUP_WEAPON_PISTOL`, `PICKUP_WEAPON_PUMPSHOTGUN` }
    for i = 1, #weaponPickups do
        ToggleUsePickupsForPlayer(playerId, weaponPickups[i], false)
    end

    SetPlayerHealthRechargeMultiplier(playerId, 0.0)

    -- Disable Dispatch services
    for i = 1, 15 do
        EnableDispatchService(i, false)
    end

    -- Disable Scenarios
    local scenarios = {
        "WORLD_VEHICLE_ATTRACTOR",
        "WORLD_VEHICLE_AMBULANCE",
        "WORLD_VEHICLE_BICYCLE_BMX",
        "WORLD_VEHICLE_BICYCLE_BMX_BALLAS",
        "WORLD_VEHICLE_BICYCLE_BMX_FAMILY",
        "WORLD_VEHICLE_BICYCLE_BMX_HARMONY",
        "WORLD_VEHICLE_BICYCLE_BMX_VAGOS",
        "WORLD_VEHICLE_BICYCLE_MOUNTAIN",
        "WORLD_VEHICLE_BICYCLE_ROAD",
        "WORLD_VEHICLE_BIKE_OFF_ROAD_RACE",
        "WORLD_VEHICLE_BIKER",
        "WORLD_VEHICLE_BOAT_IDLE",
        "WORLD_VEHICLE_BOAT_IDLE_ALAMO",
        "WORLD_VEHICLE_BOAT_IDLE_MARQUIS",
        "WORLD_VEHICLE_BOAT_IDLE_MARQUIS",
        "WORLD_VEHICLE_BROKEN_DOWN",
        "WORLD_VEHICLE_BUSINESSMEN",
        "WORLD_VEHICLE_HELI_LIFEGUARD",
        "WORLD_VEHICLE_CLUCKIN_BELL_TRAILER",
        "WORLD_VEHICLE_CONSTRUCTION_SOLO",
        "WORLD_VEHICLE_CONSTRUCTION_PASSENGERS",
        "WORLD_VEHICLE_DRIVE_PASSENGERS",
        "WORLD_VEHICLE_DRIVE_PASSENGERS_LIMITED",
        "WORLD_VEHICLE_DRIVE_SOLO",
        "WORLD_VEHICLE_FIRE_TRUCK",
        "WORLD_VEHICLE_EMPTY",
        "WORLD_VEHICLE_MARIACHI",
        "WORLD_VEHICLE_MECHANIC",
        "WORLD_VEHICLE_MILITARY_PLANES_BIG",
        "WORLD_VEHICLE_MILITARY_PLANES_SMALL",
        "WORLD_VEHICLE_PARK_PARALLEL",
        "WORLD_VEHICLE_PARK_PERPENDICULAR_NOSE_IN",
        "WORLD_VEHICLE_PASSENGER_EXIT",
        "WORLD_VEHICLE_POLICE_BIKE",
        "WORLD_VEHICLE_POLICE_CAR",
        "WORLD_VEHICLE_POLICE",
        "WORLD_VEHICLE_POLICE_NEXT_TO_CAR",
        "WORLD_VEHICLE_QUARRY",
        "WORLD_VEHICLE_SALTON",
        "WORLD_VEHICLE_SALTON_DIRT_BIKE",
        "WORLD_VEHICLE_SECURITY_CAR",
        "WORLD_VEHICLE_STREETRACE",
        "WORLD_VEHICLE_TOURBUS",
        "WORLD_VEHICLE_TOURIST",
        "WORLD_VEHICLE_TANDL",
        "WORLD_VEHICLE_TRACTOR",
        "WORLD_VEHICLE_TRACTOR_BEACH",
        "WORLD_VEHICLE_TRUCK_LOGS",
        "WORLD_VEHICLE_TRUCKS_TRAILERS",
        "WORLD_VEHICLE_DISTANT_EMPTY_GROUND",
        "WORLD_HUMAN_PAPARAZZI",
    }

    for _, v in pairs(scenarios) do
        SetScenarioTypeEnabled(v, false)
    end

    if IsScreenFadedOut() then
        DoScreenFadeIn(500)
    end

    SetDefaultVehicleNumberPlateTextPattern(-1, "........")
end)


RegisterNetEvent("primordial_core:onPlayerLogout")
AddEventHandler("primordial_core:onPlayerLogout", function()
    PL.PlayerLoaded = false
end)

RegisterNetEvent("primordial_core:client:setMaxWeight")
AddEventHandler("primordial_core:client:setMaxWeight", function(newMaxWeight)
    PL.SetPlayerData("maxWeight", newMaxWeight)
end)

local function onPlayerSpawn()
    PL.SetPlayerData("ped", PlayerPedId())
    PL.SetPlayerData("dead", false)
end

AddEventHandler("playerSpawned", onPlayerSpawn)
AddEventHandler("primordial_core:onPlayerSpawn", onPlayerSpawn)

AddEventHandler("primordial_core:onPlayerDeath", function()
    PL.SetPlayerData("ped", PlayerPedId())
    PL.SetPlayerData("dead", true)
end)

AddEventHandler("skinchanger:modelLoaded", function()
    while not PL.PlayerLoaded do
        Wait(100)
    end
    TriggerEvent("primordial_core:client:restoreLoadout")
end)

AddEventHandler("primordial_core:client:restoreLoadout", function()
    PL.SetPlayerData("ped", PlayerPedId())
end)

AddStateBagChangeHandler("VehicleProperties", nil, function(bagName, _, value)
    if not value then
        return
    end

    local netId = bagName:gsub("entity:", "")
    local vehicle = NetToVeh(tonumber(netId))

    PL.Vehicle.SetVehicleProperties(vehicle, value)
end)

RegisterNetEvent("primordial_core:setAccountMoney")
AddEventHandler("primordial_core:setAccountMoney", function(account)
    for i = 1, #PL.PlayerData.accounts do
        if PL.PlayerData.accounts[i].name == account.name then
            PL.PlayerData.accounts[i] = account
            break
        end
    end

    PL.SetPlayerData("accounts", PL.PlayerData.accounts)
end)

RegisterNetEvent("primordial_core:setJob")
AddEventHandler("primordial_core:setJob", function(Job)
    PL.SetPlayerData("job", Job)
end)

RegisterNetEvent("primordial_core:setGroup")
AddEventHandler("primordial_core:setGroup", function(group)
    PL.SetPlayerData("group", group)
end)

RegisterNetEvent("primordial_core:client:registerSuggestions")
AddEventHandler("primordial_core:client:registerSuggestions", function(registeredCommands)
    for name, command in pairs(registeredCommands) do
        if command.suggestion then
            TriggerEvent("chat:addSuggestion", ("/%s"):format(name), command.suggestion.help, command.suggestion.arguments)
        end
    end
end)

-- Disable GTA Online wanted level ( 0 stars - 5 stars )
ClearPlayerWantedLevel(PlayerId())
SetMaxWantedLevel(0)

RegisterNetEvent("primordial_core:client:showAdvancedNotification")
AddEventHandler("primordial_core:client:showAdvancedNotification", function(receiver, subject, msg, textureDict, iconType, flash, saveToBrief, hudColorIndex)
    PL.Notification.ShowAdvancedNotification(receiver, subject, msg, textureDict, iconType, flash, saveToBrief, hudColorIndex)
end)

RegisterNetEvent("primordial_core:client:showHelpNotification")
AddEventHandler("primordial_core:client:showHelpNotification", function(msg, thisFrame, beep, duration)
    PL.Notification.ShowHelpNotification(msg, thisFrame, beep, duration)
end)

RegisterNetEvent("primordial_core:client:killPlayer")
AddEventHandler("primordial_core:client:killPlayer", function()
    SetEntityHealth(PL.PlayerData.ped, 0)
end)

RegisterNetEvent("primordial_core:client:repairPedVehicle")
AddEventHandler("primordial_core:client:repairPedVehicle", function()
    local ped = PL.PlayerData.ped
    local vehicle = GetVehiclePedIsIn(ped, false)
    SetVehicleEngineHealth(vehicle, 1000)
    SetVehicleEngineOn(vehicle, true, true)
    SetVehicleFixed(vehicle)
    SetVehicleDirtLevel(vehicle, 0)
end)

RegisterNetEvent("primordial_core:client:freezePlayer")
AddEventHandler("primordial_core:client:freezePlayer", function(input)
    local player = PlayerId()
    if input == "freeze" then
        SetEntityCollision(PL.PlayerData.ped, false)
        FreezeEntityPosition(PL.PlayerData.ped, true)
        SetPlayerInvincible(player, true)
    elseif input == "unfreeze" then
        SetEntityCollision(PL.PlayerData.ped, true)
        FreezeEntityPosition(PL.PlayerData.ped, false)
        SetPlayerInvincible(player, false)
    end
end)

lib.callback.register('primordial_core:client:GetVehicleType', function(model)
    return PL.Vehicle.GetClientVehicleType(model)
end)

AddStateBagChangeHandler("metadata", "player:" .. tostring(GetPlayerServerId(PlayerId())), function(_, key, val)
    PL.SetPlayerData(key, val)
end)