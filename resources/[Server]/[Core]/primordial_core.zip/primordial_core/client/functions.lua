Core = {}
PL.PlayerData = {}
PL.PlayerLoaded = false

PL.Notification = {}

PL.Object = {}

PL.Ped = {}

PL.Player = {}

PL.Scaleform = {}
PL.Scaleform.Utils = {}

PL.Streaming = {}
PL.Streaming.Utils = {}

PL.Utils = {}

PL.Vehicle = {}



function PL.IsPlayerLoaded()
    return PL.PlayerLoaded
end

function PL.GetPlayerData()
    return PL.PlayerData
end

function PL.SetPlayerData(key, val)
    local current = PL.PlayerData[key]
    PL.PlayerData[key] = val
    if key ~= "inventory" and key ~= "loadout" then
        if type(val) == "table" or val ~= current then
            TriggerEvent("primordial_core:setPlayerData", key, val, current)
        end
    end
end

PL.HashString = function(str)
    local format = string.format
    local upper = string.upper
    local gsub = string.gsub
    local hash = joaat(str)
    local input_map = format("~INPUT_%s~", upper(format("%x", hash)))
    input_map = gsub(input_map, "FFFFFFFF", "")

    return input_map
end

---@param account string Account name (money/bank/black_money)
---@return table|nil
function PL.GetAccount(account)
    for i = 1, #PL.PlayerData.accounts, 1 do
        if PL.PlayerData.accounts[i].name == account then
            return PL.PlayerData.accounts[i]
        end
    end
    return nil
end