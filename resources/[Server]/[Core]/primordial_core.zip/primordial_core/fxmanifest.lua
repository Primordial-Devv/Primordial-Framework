fx_version 'cerulean'

game 'gta5'

author 'Primordial Studio'

description 'Framework of Primordial Studio (modified from ESX)'

version '2.7.2'

name 'Primordial Core'

lua54 'yes'

shared_scripts {
	'@ox_lib/init.lua',
	'translations/*.lua',

	'shared/common.lua',
	'shared/functions.lua',

	'shared/modules/functions/math/*.lua',
	'shared/modules/functions/print/*.lua',
	'shared/modules/functions/table/*.lua',
	'shared/modules/functions/timeout.lua',

	'config.lua',
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',

	-- 'server/migrations/society.lua',

	'config.logs.lua',

	'server/common.lua',

	'server/classes/player.lua',
	'server/classes/society.lua',

	'server/functions.lua',

	'server/modules/society.lua',
	'server/modules/playerLicense.lua',
	'server/paycheck.lua',

	'server/main.lua',
	'server/modules/functions/discord/*.lua',
	'server/commands.lua',

	'server/modules/functions/notification/*.lua',
	'server/modules/functions/object/*.lua',
	'server/modules/functions/ped/*.lua',
	'server/modules/functions/player/*.lua',
	'server/modules/functions/vehicle/*.lua',
	'server/modules/functions/utils/*.lua',

	'server/modules/actions.lua',
}

client_scripts {
	'client/functions.lua',

	'client/main.lua',

	'client/modules/actions.lua',
	'client/modules/death.lua',
	'client/modules/society.lua',

	'client/modules/functions/utils/*.lua',
	'client/modules/functions/notification/*.lua',
	'client/modules/functions/object/*.lua',
	'client/modules/functions/ped/*.lua',
	'client/modules/functions/player/*.lua',
	'client/modules/functions/scaleform/*.lua',
	'client/modules/functions/streaming/*.lua',
	'client/modules/functions/vehicle/*.lua',
}

files {
	'init.lua',
}

server_exports {
    --'GetSocietyAccount',
    --'AddSocietyAccount'
}

dependencies {
	'/native:0x6AE51D4B',
    '/native:0xA61C8FC6',
	'oxmysql',
	'spawnmanager',
}
