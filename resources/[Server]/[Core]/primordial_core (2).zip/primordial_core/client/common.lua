PL.PlayerData = {}

PL.Notification = {}

PL.Object = {}

PL.Ped = {}

PL.Player = {}

PL.Scaleform = {}
PL.Scaleform.Utils = {}

PL.Streaming = {}
PL.Streaming.Utils = {}

PL.Utils = {}

PL.Vehicle = {}