AccountsFramework = {
    bank = {
        label = Translations.account_bank,
        round = true,
    },
    black_money = {
        label = Translations.account_black_money,
        round = true,
    },
    money = {
        label = Translations.account_money,
        round = true,
    },
}

EnableDebug = false -- Use Debug options?