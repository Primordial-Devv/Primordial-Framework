PermissionsGroups = {
    ["owner"] = true,
    ["admin"] = true,
}