StartingAccountMoney = { bank = 50000 }

StartingInventoryItems = {
    {name = 'burger', count = 5, slot = 1},
    {name = 'water', count = 5, slot = 2},
    {name = 'money', count = 1500, slot = 3}
} -- table/false

DefaultSpawnPosition = {
    { x = 222.2027, y = -864.0162, z = 30.2922, heading = 1.0 },
}