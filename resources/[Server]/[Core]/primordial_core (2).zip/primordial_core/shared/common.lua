PL = {}
PL.Type = {}
PL.Math = {}
PL.Table = {}
PL.Print = {}
PL.String = {}
PL.Object = {}
PL.Ped = {}
PL.Utils = {}

exports("getSharedObject", function()
    return PL
end)