MaxEmployeeSalary = 3500

SocietyBossGrades = { -- Uncomment and/or add additional grades you want to have access to the boss menu.
    ['boss'] = true,
    ['second'] = true,
}